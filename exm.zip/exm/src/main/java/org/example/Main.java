package org.example;

import java.util.ArrayList;
import java.util.List;


public class Main {
    public static void main(String[] args) {

        // retrive Matrix
        // build matrix with n and m nxm
        int n = 3;
        int m =3;
        int [][] matrix2 =  {
            {3, 2, 1},
            {5, 11, 5},
            {3, 0, 13}
        };
        int k=24;

        // find available path to check xor values

        // create structure with path and xor value.
        // find the number of the paths with the Xor equals to K


/**
 *
 *                        3 3 Xornum
 *                       { 3, 2, 1 },
 *                       { 5, 11, 5 },
 *                       { 3, 0, 13 },
 *
 *
 */

    List<Path> paths = getPaths(n,m);
    paths.forEach(path -> path.printPoints());
    System.out.println(paths.stream().filter(i->i.calculateXor(matrix2)==k).count());
    }

    private static List<Path> getPaths(int n, int m) {
        List<Path> paths = new ArrayList<>();
        buildpath(0,0,n,m,new ArrayList<>(),paths);
        return paths;
    }
    private static void buildpath(int row,int culomn,int n, int m,List<Point> mypath,List<Path> paths )
    {
        //end of the matrix
        if(row>=n || culomn>=m)
            return;

        Point p = new Point(row, culomn);
        mypath.add(p);
        //if we reach the last
        if(row==n-1 && culomn==m-1)
        {
            paths.add(new Path(new ArrayList<>(mypath)));
        }
        else{
            buildpath(row+1,culomn,n,m,mypath,paths);
            buildpath(row,culomn+1,n,m,mypath,paths);
        }
        //if we don't remove it will store points from last path
        mypath.remove(mypath.size() - 1);

    }
}
class Point
{
    int value;
    int row;
    int culomn;
    Point(int row,int culomn)
    {
        this.culomn=culomn;
        this.row=row;
    }
}
class Path
{
    ArrayList<Point> points;
    Path(ArrayList<Point> points) {
        this.points = points;
    }
    int calculateXor(int[][] matrix)
    {
        //return the sum of the elements in path to xor->reduce(0, (a, b) -> a ^ b);
        return points.stream().mapToInt(i->matrix[i.row][i.culomn]).sum();
    }


    public void printPoints() {
        String print="";
        for(Point p:points )
        {
            print+= "("+p.row+","+p.culomn+")";
        }
        System.out.println(print);

    }

}